#include <stdio.h>
#include <stdlib.h>

int main()
{
    int entero;
    float flotante;
    char caracter;

    printf("Ingrese un entero ");
    scanf("%d",&entero);

    printf("Ingrese un flotante");
    scanf("%f",&flotante);

    printf("Ingrese un caracter ");
    //fflush(stdin);no vamos a utilizar esto,
    caracter=getche();
    //scanf("%c",&caracter);

    printf("El entero es %d\nEl flotante es %2f\nEl caracter es %c ", entero, flotante, caracter);

    return 0;
}
